const fs = require('fs')

global.owner = "62"
global.status = false 
global.imageBuffer = fs.readFileSync('./media/caywzz.jpg'); // Buffer Image
global.typereply = 'v4'; // Gaya Reply v1-v4
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat"
}

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
